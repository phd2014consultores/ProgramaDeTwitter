/*
Programa de Prueba para la extraer informacion generada en Twitter
 */


package Controlador;

import Vista.Ventana_Principal;


/**
 *
 * @author David Botello
 */
public class TwitterApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Ventana_Principal();
    //    new msqlconection().coneccion();
    }
    
}
